# Mega Plan ZIP — APK de comprobación

Fecha: 29 de octubre de 2026.

`public/downloads/DeadStrikeReborn-MegaPlan-checkpoint.apk` contiene los assets web actuales del proyecto y reutiliza el contenedor Android, el manifiesto binario y `classes.dex` del APK v3.0 que ya existía en el repositorio.

## Tablero de seguimiento

| Hecho / integrado | Pendiente / no verificado |
|---|---|
| Asset web actual preparado dentro de un APK de comprobación; integridad ZIP y firma local v1/v2 comprobadas. | Instalar y ejecutar en teléfono; comprobar pantalla negra y recorrido del mapa. |
| Sintaxis de módulos JS y pruebas lógicas básicas pasan. | Validación con `apksigner`/Android SDK oficial y compilación Android completa. |
| Se conserva el APK v3.0 original sin sobrescribir. | Editor completo del HUD, niveles independientes, progresión, cinemática de muerte y ajustes reales de gráficos/FPS. |

## Verificaciones realizadas

- ZIP íntegro, con todos los assets actuales y módulos JavaScript referenciados.
- `resources.arsc` almacenado sin compresión y con datos alineados a cuatro bytes.
- La firma v1 se verificó con `jarsigner`; la estructura y firma criptográfica v2 se auto-verificaron con un script local.
- El JavaScript del proyecto pasa `node --check`; las pruebas unitarias básicas de misión, economía y oleadas pasan.

## Límites que siguen abiertos

- No se dispone de Android SDK/build-tools en el entorno; no fue posible ejecutar `aapt`, `d8`, `zipalign` o `apksigner` oficial.
- No se pudo instalar ni ejecutar en un teléfono ni verificar el comportamiento visual. La pantalla negra y la desaparición del mapa no se consideran resueltas hasta completar esa prueba.
- El APK conserva el contenedor nativo v3.0; no es una compilación Android completa desde cero de todos los recursos fuente.
- El keystore privado de la firma anterior no está disponible, así que esta copia usa una firma nueva. Para instalarla, se debe desinstalar la versión anterior primero; eso puede borrar datos guardados localmente. No la instales encima de la anterior esperando una actualización.
- Esta es una versión de comprobación, no la entrega final del Mega Plan. Sigue pendiente completar el editor total del HUD, niveles separados, cinemática de muerte, ajustes reales de calidad/FPS y las pruebas de ejecución.
