## Tablero de seguimiento — Mega Plan

> Regla de trabajo: un bloque integrado y comprobado se conserva cerrado. Solo se reabre si una prueba posterior demuestra un defecto. “Integrado” no equivale a “verificado en teléfono”.

| Bloque | Estado | Evidencia / siguiente paso |
|---|---|---|
| Manejo visible de errores y pérdida de WebGL | **Integrado; sintaxis verificada** | La interfaz muestra un aviso y detiene el bucle defectuoso; falta provocar/probar el caso en Android. |
| Integridad del proyecto y sintaxis JS | **Verificado estáticamente** | `node --check` pasa para módulos de `src/game/`; las pruebas de lógica básicas pasan. |
| Texturas, materiales y animación zombie | **Integrado parcialmente** | Falta revisión visual y rendimiento en el móvil. |
| Cámara, niebla y mapa persistente | **Ajustes integrados; causa raíz no confirmada** | Falta prueba de recorrido real; no se marca como corregido todavía. |
| Menú, recursos y orientación horizontal | **Integrado parcialmente** | Falta comprobar botones y comportamiento en ejecución. |
| APK de comprobación | **Generado; no instalado ni validado con herramientas Android oficiales** | Usa contenedor nativo v3.0 y firma nueva; desinstalar la versión previa puede borrar datos. |
| Editor completo del HUD | **Pendiente** | Mover/redimensionar/opacity para todos los controles, hitboxes, guardar/restaurar. |
| Niveles independientes y progresión | **Pendiente** | Selección de nivel y continuidad de partida guardada. |
| Cinemática de muerte y sistemas restantes | **Pendiente** | Reintentar/menú, tienda y perfil/salida completamente funcionales, ajustes reales de calidad/FPS. |
| Pruebas visuales y en teléfono | **Pendiente** | Arranque, recorrido, controles, menú, memoria y rendimiento. |
| APK final del Mega Plan | **Pendiente** | Requiere completar sistemas restantes y validar la instalación/ejecución. |

# Dead Strike Reborn — cambios integrados en el paquete de trabajo

## Cambios aplicados
- Se añadió un recorte optimizado de la referencia elegida para el menú: Valeria en primer plano y la ciudad destruida como fondo atmosférico, manteniendo los botones funcionales del juego por separado.
- Se añadió manejo visible de errores de arranque en React y en la plantilla HTML del APK. En esta revisión también se agregó un guardián al bucle de animación: si el contexto WebGL se pierde o `tick`/`render` lanza una excepción, se muestra un aviso visible y se detiene el bucle que falla, en vez de repetir el error indefinidamente.
- Se amplió la distancia de recorte de cámara a 180 unidades y se redujo la densidad exponencial de niebla a día 0.00135, noche 0.0018 y lluvia nocturna 0.00225. La niebla se conserva como atmósfera, pero su curva ya no debería borrar el mapa a distancias cortas; requiere prueba caminando por el escenario.
- Se añadieron marcas de heridas persistentes y ligeras en los zombis alcanzados por disparos (máximo de cinco por enemigo) usando geometría/material compartidos para reducir asignaciones y mantener rendimiento. El código también contiene cuatro activadores de zombis que caen desde ventanas, con caída física simplificada y posterior persecución; la secuencia requiere prueba visual en ejecución.
- Al recibir daño, Valeria ahora tiene una sacudida más marcada y una pequeña reacción de orientación, sin bloquear el control del jugador.
- El ambiente ahora se selecciona al inicio de cada misión y se mantiene estable durante esa partida; se retiró el control manual de clima.
- Se protegió la lectura inicial de localStorage del editor de joystick para que el almacenamiento bloqueado no interrumpa el arranque.
- Se añadió una pantalla bloqueante para orientación vertical en web, solicitud de bloqueo horizontal al iniciar y verificación de orientación horizontal en el manifiesto Android.
- Se activó hardware acceleration en el manifiesto Android y se añadió el MIME `image/webp` al servidor de recursos del WebView para cargar correctamente el arte del menú.
- Se ajustó el script de empaquetado para localizar el proyecto desde su propia carpeta y usar la ruta de Android SDK configurable.
- Se incorporó el ZIP de especificaciones y el documento maestro en `docs/` para que el siguiente agente pueda continuar sin perder requisitos.

## Mejoras visuales adicionales de esta revisión
- Se añadieron mapas normales derivados de las texturas procedurales para el asfalto y las fachadas, además de mapas de relieve y rugosidad para concreto, pavimento y acero; el objetivo es que las superficies respondan a la iluminación y no dependan solo del color plano.
- Se aumentó el límite de resolución interna del renderizador a 1.5× en táctil y 1.85× en escritorio, manteniendo el límite para no multiplicar sin control el coste de GPU en móviles.
- Se mejoró el ciclo procedural de los zombis con movimiento desigual de hombros, inclinación del torso, variación de cabeza y anticipación del ataque; conserva el rig y la IA existentes.

## Verificaciones realizadas
- ZIP original del proyecto: prueba de integridad correcta, sin errores de compresión.
- Sintaxis de todos los módulos JavaScript en `src/game/`: comprobada con `node --check`.
- Sintaxis Python del script de empaquetado: comprobada con `py_compile`.
- Manifiesto Android: verificado que mantiene `screenOrientation="landscape"` y ahora activa aceleración por hardware.

## Pendiente / no verificado
- `node --check` pasó para todos los módulos JavaScript de `src/game/`, incluido el cambio al manejo de errores.
- Se ejecutaron pruebas de lógica con Node para bifurcación de misión, ruta larga, suministro, objetivo de extracción, compra en tienda, crédito insuficiente y estado/avance de oleadas; pasaron.
- La comprobación estática del paquete preparado confirmó que los módulos importados, estilos, iconos y arte del menú están presentes.
- Se generó un APK de comprobación a partir del contenedor Android v3.0 existente, sustituyendo los assets de juego por los actuales. El ZIP pasa integridad; `resources.arsc` está sin comprimir y alineado a 4 bytes; la firma JAR/v1 se validó y la firma v2 se comprobó criptográficamente con un verificador local. No se pudo contrastar con `apksigner` oficial ni instalarlo en un dispositivo.
- No se pudo completar `npm run build`: el entorno no tiene `vite` instalado; el intento de instalar dependencias agotó el tiempo disponible y la descarga de herramientas Android falla por DNS bloqueado.
- No se encontró Android SDK/build-tools (`aapt`, `d8`, `zipalign`, `apksigner`) y no hay conexión DNS para descargarlos. Por eso el APK de comprobación reutiliza el contenedor Android y `classes.dex` del APK v3.0 existente; no equivale a una compilación Android completa desde el código fuente. Se conserva intacto el APK v3.0 original.
- El APK de comprobación lleva una identidad de firma nueva porque no se encontró el keystore privado original; no puede instalarse como actualización sobre el APK anterior. Para probarlo sería necesario desinstalar primero la versión anterior, lo cual puede borrar su progreso local. Esta condición y la falta de prueba en teléfono deben resolverse antes de distribuirlo.
- La corrección de niebla, las heridas y el menú necesitan prueba visual en ejecución; los cambios de código no equivalen a una prueba dentro del juego ni en el Samsung.
- Hay una sola misión principal con elección de ruta; faltan niveles independientes y una pantalla de selección/progresión de niveles.
- Las caídas de zombis desde ventanas y marcas de heridas ya existen en el código, pero no se han verificado visualmente. La secuencia de muerte sigue siendo una pantalla final/modal, no una cinemática terminada.
- El editor existente personaliza el joystick; falta extenderlo a todos los elementos del HUD con hitboxes sincronizadas. Las opciones reales de 30/60/120 FPS y perfiles de calidad gráfica todavía no están completadas.
- El menú conserva inicio, tienda/refugio y equipo; falta una experiencia independiente de perfil, salida y continuación de partida verdaderamente guardada.
- Chromium no permitió abrir la página local en este entorno y Playwright no tiene su navegador descargado, así que la prueba visual y de recorrido todavía está bloqueada. No se declara resuelto el fallo del mapa que desaparece hasta probarlo en ejecución.
