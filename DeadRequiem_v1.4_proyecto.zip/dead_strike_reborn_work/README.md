<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/09b0471e-75a2-41c0-805d-adc242e39cf1

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Estado de esta entrega

Paquete de trabajo con menú cinematográfico, refuerzo del arranque, orientación horizontal, ajuste de niebla/distancia de cámara, heridas persistentes en zombis y reacción al recibir daño. La sintaxis JavaScript/Python se ha comprobado. La compilación web y las pruebas en Android siguen pendientes porque este entorno no tiene las dependencias de construcción instaladas ni Android SDK disponible.
