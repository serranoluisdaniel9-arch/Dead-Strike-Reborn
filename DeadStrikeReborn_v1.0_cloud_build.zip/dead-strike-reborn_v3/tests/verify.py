"""Headless verification for Dead Strike Reborn v1.0.

Drives the real page in Chromium (software GL), exercises the run loop, buys
gear through the actual shop buttons, walks to the route fork, then reloads and
opens a second browser context to prove the profile really persists.

Run:  python3 tests/verify.py            (expects a static server on :8099)
Exit: 0 when every check passes.
"""
import json
import sys

from playwright.sync_api import sync_playwright

BASE = 'http://127.0.0.1:8099/index.html'
GL = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']

results = []


def check(name, ok, detail=''):
    results.append((name, bool(ok), detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f'  — {detail}' if detail else ''))


def attach(page, errors, failed):
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.on('pageerror', lambda e: errors.append(f'PAGEERROR {e}'))
    page.on('requestfailed',
            lambda r: failed.append(f'{r.url.split("/")[-1]}: {r.failure}'))


def start_run(page):
    page.wait_for_function("() => !document.getElementById('start').disabled", timeout=20000)
    # A headless window can lose focus and auto-pause; clear any overlay first.
    page.evaluate('''() => {
      for (const id of ['paused', 'shop', 'route', 'joystick-editor']) {
        document.getElementById(id)?.classList.add('hidden');
      }
    }''')
    page.wait_for_timeout(200)
    page.click('#start')
    page.wait_for_function(
        "() => window.__gameState && window.__gameState().phase === 'playing'", timeout=15000)
    page.wait_for_timeout(900)


def walk_to_fork(page):
    """Place the player on the fork (software GL is ~50x slower than real time)."""
    page.evaluate('() => window.__debugTeleport(0, 8.4)')
    page.wait_for_timeout(500)


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=GL)

        # ---------------------------------------------------------------- session 1
        ctx = browser.new_context(viewport={'width': 1280, 'height': 720})
        page = ctx.new_page()
        errors, failed = [], []
        attach(page, errors, failed)
        page.goto(BASE + '?debug=1', wait_until='load')
        page.wait_for_timeout(2400)

        check('page boots and the start button unlocks',
              page.evaluate("() => !document.getElementById('start').disabled"))
        check('no console errors on boot', not errors, f'{len(errors)}: {errors[:3]}')
        check('no failed requests on boot', not failed, f'{len(failed)}: {failed[:3]}')

        # ---- shop from the intro screen, driven by real clicks ----
        page.evaluate('''async () => {
          const m = await import('./economy-rules.js');
          const raw = m.loadProfile();
          raw.credits = 2000;
          m.saveProfile(raw);
        }''')
        page.reload(wait_until='load')
        page.wait_for_timeout(2400)
        page.click('#intro-shop')
        page.wait_for_timeout(500)

        def buy(kind, item_id):
            # Each category lives on its own tab: Suministros / Armas / Aspectos.
            tab = {'ammo': 0, 'weapon': 1, 'skin': 2}[kind]
            page.click(f'.shop-tab >> nth={tab}')
            page.wait_for_timeout(250)
            page.click(f'button.shop-action[data-kind="{kind}"][data-id="{item_id}"]')
            page.wait_for_timeout(650)

        card_count = page.evaluate("() => document.querySelectorAll('.shop-card').length")
        buy('weapon', 'revolver')
        buy('ammo', 'revolver')
        buy('skin', 'reborn')
        after_buy = page.evaluate('''async () => (await import('./economy-rules.js')).loadProfile()''')
        check('shop renders a card per weapon, skin and ammo line', card_count == 15,
              f'{card_count} cards (5 weapons + 5 skins + 5 ammo)')
        check('revolver bought through the shop UI',
              'revolver' in after_buy['ownedWeapons'], str(after_buy['ownedWeapons']))
        check('per-weapon ammo bought through the shop UI',
              after_buy['ammo']['revolver'] == 12, f"rounds={after_buy['ammo']['revolver']}")
        check('Renacida skin bought', 'reborn' in after_buy['ownedSkins'])
        check('credits debited 320 + 22 + 420',
              after_buy['credits'] == 2000 - 320 - 22 - 420, f"credits={after_buy['credits']}")

        ammo_label = page.evaluate(
            "() => document.querySelector('button.shop-action[data-kind=\"ammo\"][data-id=\"revolver\"]').textContent")
        check('revolver ammo shows its per-gun state', 'Comprar' in ammo_label or 'reserva' in ammo_label,
              ammo_label)

        page.click('.shop-close')
        page.wait_for_timeout(400)

        # ---- reload: the profile must survive ----
        page.reload(wait_until='load')
        page.wait_for_timeout(2400)
        reloaded = page.evaluate('''async () => (await import('./economy-rules.js')).loadProfile()''')
        check('profile survives a page reload',
              'revolver' in reloaded['ownedWeapons'] and reloaded['ammo']['revolver'] == 12,
              json.dumps({k: reloaded[k] for k in ('credits', 'weapon', 'skin', 'ammo')}))
        check('equipped skin restored on reload', reloaded['skin'] == 'reborn',
              reloaded['skin'])
        check('wallet restore keeps the debited balance',
              reloaded['credits'] == 2000 - 320 - 22 - 420, f"credits={reloaded['credits']}")

        # ---- a real run ----
        start_run(page)
        st = page.evaluate('() => window.__gameState()')
        check('run starts in playing phase', st['phase'] == 'playing', st['phase'])
        check('36 base enemies spawned', st['enemies'] == 36, f"{st['enemies']} enemies")
        check('equipped weapon is the revolver', st['weapon'] == 'revolver', st['weapon'])
        check('revolver starts with a 6-round cylinder', st['ammo'] == 6, f"ammo={st['ammo']}")
        check('bought rounds are spent into the reserve', st['reserve'] == 12,
              f"reserve={st['reserve']}")
        check('Renacida lowers max health to 75', st['run']['maxHealth'] == 75,
              f"maxHealth={st['run']['maxHealth']}")
        check('blob shadows cover player + 36 enemies',
              st['visuals']['blobShadows'] == 37, f"{st['visuals']['blobShadows']}")
        check('shadow map follows the touch flag',
              st['visuals']['shadowMap'] is (not st['visuals']['touch']),
              f"shadowMap={st['visuals']['shadowMap']} touch={st['visuals']['touch']}")

        # Walking: W must move the player along -z. The clock is advanced
        # deterministically because software GL renders far slower than real time.
        before = page.evaluate('() => window.__gameState().position')
        page.keyboard.down('w')
        page.evaluate('() => window.__debugAdvance(1.2)')
        page.keyboard.up('w')
        after = page.evaluate('() => window.__gameState().position')
        check('W walks forward (z decreases)', after[2] < before[2] - 0.5,
              f'{before[2]:.2f} -> {after[2]:.2f}')

        # Aim
        fov = page.evaluate('() => window.__gameState().fov')
        page.keyboard.press('c')
        page.evaluate('() => window.__debugAdvance(0.6)')
        fov_aim = page.evaluate('() => window.__gameState().fov')
        page.keyboard.press('c')
        page.evaluate('() => window.__debugAdvance(0.4)')
        check('aiming narrows FOV', fov_aim < fov - 3, f'{fov:.1f} -> {fov_aim:.1f}')

        # Shooting: rotate with Q/E onto the nearest enemy, then fire.
        landed, shot = False, None
        for _ in range(40):
            page.evaluate('''() => {
              const s = window.__gameState(true);
              const p = s.position;
              let best = null, d = 1e9;
              for (const e of s.population) {
                const dd = Math.hypot(e.x - p[0], e.z - p[2]);
                if (dd < d) { d = dd; best = e; }
              }
              if (!best) return;
              const want = Math.atan2(best.x - p[0], -(best.z - p[2]));
              const cur = window.__gameState().yaw;
              let delta = want - cur;
              while (delta > Math.PI) delta -= Math.PI * 2;
              while (delta < -Math.PI) delta += Math.PI * 2;
              if (Math.abs(delta) < 0.06) {
                window.dispatchEvent(new KeyboardEvent('keydown', {code: 'Space'}));
              } else {
                const code = delta > 0 ? 'KeyQ' : 'KeyE';
                window.dispatchEvent(new KeyboardEvent('keydown', {code}));
                window.dispatchEvent(new KeyboardEvent('keyup', {code}));
              }
            }''')
            page.evaluate('() => window.__debugAdvance(0.25)')
            shot = page.evaluate('() => window.__gameState().lastShot')
            if shot and shot['impact'] == 'enemy':
                landed = True
                break
        check('shooting registers an enemy hit', landed, json.dumps(shot)[:120])
        st2 = page.evaluate('() => window.__gameState()')
        check('firing consumes a round', st2['ammo'] < 6, f"ammo={st2['ammo']}")
        feedback = page.evaluate('''() => ({
          numbers: document.querySelectorAll('.damage-number').length,
          marker: document.querySelector('.hitmarker').classList.contains('active'),
          shake: (document.getElementById('game').style.transform || '') !== '',
        })''')
        check('impact feedback renders (hitmarker / numbers / shake)',
              feedback['numbers'] > 0 or feedback['marker'] or feedback['shake'],
              json.dumps(feedback))

        # ---- route fork: walk there and interact ----
        walk_to_fork(page)
        near = page.evaluate('() => window.__gameState().interaction')
        check('player reaches the route fork', near == 'fork', str(near))
        page.keyboard.press('f')
        page.wait_for_timeout(450)
        cards = page.evaluate("() => document.querySelectorAll('#route .route-card').length")
        short_meta = page.evaluate(
            "() => document.querySelector('#route-short .route-meta').textContent")
        long_meta = page.evaluate(
            "() => document.querySelector('#route-long .route-meta').textContent")
        check('route fork offers two paths', cards == 2, f'{cards} cards')
        check('short route advertises extra enemies', '+6' in short_meta, short_meta)
        check('long route advertises the supplies bonus', '+15' in long_meta, long_meta)

        page.click('#route-long')
        page.wait_for_timeout(450)
        routed = page.evaluate('() => window.__gameState()')
        check('choosing the long route advances the mission',
              routed['route'] == 'long' and routed['routeStage'] == 'extraction',
              f"route={routed['route']} stage={routed['routeStage']}")

        check('no console errors across the whole session', not errors,
              f'{len(errors)}: {errors[:4]}')
        check('no failed requests across the whole session', not failed,
              f'{len(failed)}: {failed[:4]}')
        ctx.close()

        # ---------------------------------------------------------------- session 2
        ctx2 = browser.new_context(viewport={'width': 390, 'height': 844},
                                   has_touch=True, is_mobile=True)
        page2 = ctx2.new_page()
        errors2, failed2 = [], []
        attach(page2, errors2, failed2)
        page2.goto(BASE + '?touch=1', wait_until='load')
        page2.wait_for_timeout(2600)
        editor_open = page2.evaluate(
            "() => !document.getElementById('joystick-editor').classList.contains('hidden')")
        check('first launch opens the joystick editor on touch', editor_open)
        page2.keyboard.press('Escape')
        page2.wait_for_timeout(400)
        start_run(page2)
        st3 = page2.evaluate('() => window.__gameState()')
        check('touch mode detected', st3['visuals']['touch'] is True)
        check('shadow map stays off on touch', st3['visuals']['shadowMap'] is False)
        check('blob shadows still ground everyone on touch',
              st3['visuals']['blobShadows'] == 37, f"{st3['visuals']['blobShadows']}")
        check('a separate browser context has its own empty profile',
              st3['profile']['credits'] == 0, f"credits={st3['profile']['credits']}")
        check('no console errors in the mobile session', not errors2, str(errors2[:3]))
        check('no failed requests in the mobile session', not failed2, str(failed2[:3]))
        ctx2.close()
        browser.close()

    passed = sum(1 for _, ok, _ in results if ok)
    total = len(results)
    print(f'\n{passed}/{total} checks passed')
    return 0 if passed == total else 1


if __name__ == '__main__':
    sys.exit(main())
