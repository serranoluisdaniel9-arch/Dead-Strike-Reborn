// Fictional, local-only credits: no real money, server verification or cheating protection.
// The game owns extraction eligibility; these pure helpers only settle local progress.
export const ECONOMY_KEY = 'distrito09.profile.v2';
export const LEGACY_ECONOMY_KEY = 'distrito09.profile.v1';
export const PROFILE_VERSION = 2;

// v1.0 balance pass: escaping pays less and gear costs more, so a loadout is a
// decision rather than a formality. Every number below is the single source of
// truth for both the shop UI and the run.
export const EXTRACTION_REWARD = 35;
export const SUPPLIES_BONUS = 15;

function deepFreeze(value) {
  for (const child of Object.values(value)) {
    if (child && typeof child === 'object') deepFreeze(child);
  }
  return Object.freeze(value);
}

/**
 * `moveScale` is the tension on movement speed while carrying the weapon, and
 * `pellets` > 1 turns a single trigger pull into a spread of independent rays.
 * `ammo` describes the only way to buy rounds for that weapon.
 */
export const WEAPONS = deepFreeze({
  pistol: {
    id: 'pistol', name: 'Pistola 9 mm', price: 0, magazine: 12, damage: 45,
    cooldown: .29, reload: 1.6, range: 30, aimRange: 36, noise: 32, recoil: .065,
    moveScale: 1, pellets: 1, spread: 0, startReserve: 18,
    ammo: { price: 14, amount: 12, maxPacks: 3, label: 'Caja 9 mm · 12 balas' },
  },
  revolver: {
    id: 'revolver', name: 'Revólver R-6', price: 320, magazine: 6, damage: 90,
    cooldown: .6, reload: 2.2, range: 25, aimRange: 34, noise: 40, recoil: .105,
    moveScale: .97, pellets: 1, spread: 0, startReserve: 0,
    ammo: { price: 22, amount: 12, maxPacks: 3, label: 'Caja .357 · 12 balas' },
  },
  smg: {
    id: 'smg', name: 'Vípera MP-9', price: 480, magazine: 24, damage: 28,
    cooldown: .11, reload: 1.9, range: 24, aimRange: 30, noise: 38, recoil: .042,
    moveScale: .95, pellets: 1, spread: .012, startReserve: 0,
    ammo: { price: 26, amount: 36, maxPacks: 3, label: 'Cargador MP-9 · 36 balas' },
  },
  shotgun: {
    id: 'shotgun', name: 'Quiebra-12', price: 620, magazine: 5, damage: 26,
    cooldown: .78, reload: 2.8, range: 16, aimRange: 20, noise: 48, recoil: .16,
    moveScale: .88, pellets: 6, spread: .055, startReserve: 0,
    ammo: { price: 30, amount: 15, maxPacks: 3, label: 'Caja del 12 · 15 cartuchos' },
  },
  rifle: {
    id: 'rifle', name: 'Cerraja-7', price: 780, magazine: 8, damage: 120,
    cooldown: .85, reload: 2.6, range: 46, aimRange: 60, noise: 46, recoil: .13,
    moveScale: .82, pellets: 1, spread: 0, startReserve: 0,
    ammo: { price: 34, amount: 16, maxPacks: 3, label: 'Peine 7,62 · 16 balas' },
  },
});

/**
 * Skins are no longer cosmetic-only: each one trades something away. The
 * `modifiers` are additive deltas applied at run start.
 */
export const SKINS = deepFreeze({
  survivor: {
    id: 'survivor', name: 'Superviviente', price: 0, jacket: '#405c68',
    pants: '#493d39', hair: '#302c29', backpack: '#6e5b43',
    modifiers: { health: 0, speed: 0, damage: 0 },
    tension: 'Sin modificadores. La referencia.',
  },
  crimson: {
    id: 'crimson', name: 'Guardia carmesí', price: 180, jacket: '#743f46',
    pants: '#303740', hair: '#302c29', backpack: '#50483c',
    modifiers: { health: 20, speed: -.04, damage: 0 },
    tension: '+20 vitales, −4% velocidad.',
  },
  olive: {
    id: 'olive', name: 'Exploradora', price: 240, jacket: '#626b43',
    pants: '#383b36', hair: '#6a4934', backpack: '#4b443b',
    modifiers: { health: -10, speed: .09, damage: 0 },
    tension: '+9% velocidad, −10 vitales.',
  },
  reborn: {
    id: 'reborn', name: 'Renacida', price: 420, jacket: '#25282a',
    pants: '#293b50', hair: '#bda36c', backpack: '#4b4236',
    modifiers: { health: -25, speed: .15, damage: 0 },
    tension: '+15% velocidad, −25 vitales. Frágil y rápida.',
  },
  ash: {
    id: 'ash', name: 'Chatarrera', price: 300, jacket: '#4a4a44',
    pants: '#2f3330', hair: '#8a7a5e', backpack: '#5c5344',
    modifiers: { health: 0, speed: -.06, damage: .12 },
    tension: '+12% daño, −6% velocidad.',
  },
});

const MAX_CREDITS = 999999;
const MAX_COMPLETED_RUNS = 128;
const hasOwn = (object, key) =>
  typeof key === 'string' && Object.prototype.hasOwnProperty.call(object, key);
const integer = (value, max) =>
  Number.isFinite(value) ? Math.max(0, Math.min(max, Math.trunc(value))) : 0;
const validRunId = value =>
  typeof value === 'string' && value.length > 0 && value.length <= 128 &&
  value.trim().length > 0 && !/[\u0000-\u001f\u007f]/.test(value);

const emptyAmmo = () => Object.fromEntries(Object.keys(WEAPONS).map(id => [id, 0]));

export function defaultProfile() {
  return {
    version: PROFILE_VERSION,
    credits: 0,
    ownedWeapons: ['pistol'],
    ownedSkins: ['survivor'],
    weapon: 'pistol',
    skin: 'survivor',
    ammo: emptyAmmo(),
    completedRuns: [],
    firstRunDone: false,
  };
}

/** v1 profiles had a single `ammoPacks` counter; convert it to pistol rounds. */
function migrate(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null;
  if (input.version === PROFILE_VERSION) return input;
  if (input.version !== 1) return null;
  const packs = integer(input.ammoPacks, 2);
  return {
    ...input,
    version: PROFILE_VERSION,
    ammo: { ...emptyAmmo(), pistol: packs * 6 },
    firstRunDone: Array.isArray(input.completedRuns) && input.completedRuns.length > 0,
  };
}

export function normalizeProfile(input) {
  const source = migrate(input);
  if (!source) return defaultProfile();
  const ownedIds = (ids, catalog, fallback) => [...new Set([
    fallback, ...(Array.isArray(ids) ? ids.filter(id => hasOwn(catalog, id)) : []),
  ])];
  const ownedWeapons = ownedIds(source.ownedWeapons, WEAPONS, 'pistol');
  const ownedSkins = ownedIds(source.ownedSkins, SKINS, 'survivor');
  const ammo = emptyAmmo();
  if (source.ammo && typeof source.ammo === 'object' && !Array.isArray(source.ammo)) {
    for (const id of Object.keys(WEAPONS)) {
      const cap = WEAPONS[id].ammo.amount * WEAPONS[id].ammo.maxPacks;
      ammo[id] = integer(source.ammo[id], cap);
    }
  }
  return {
    version: PROFILE_VERSION,
    credits: integer(source.credits, MAX_CREDITS),
    ownedWeapons,
    ownedSkins,
    weapon: ownedWeapons.includes(source.weapon) ? source.weapon : 'pistol',
    skin: ownedSkins.includes(source.skin) ? source.skin : 'survivor',
    ammo,
    completedRuns: [...new Set(
      Array.isArray(source.completedRuns) ? source.completedRuns.filter(validRunId) : [],
    )].slice(-MAX_COMPLETED_RUNS),
    firstRunDone: source.firstRunDone === true,
  };
}

/**
 * `kind` is 'weapon' | 'skin' | 'ammo'. For ammo, `id` is the weapon whose
 * rounds are being bought, and the stock cap is per weapon.
 */
export function purchase(profile, kind, id) {
  const next = normalizeProfile(profile);
  const fail = message => ({ profile: next, ok: false, message });
  let item;
  let ownedKey;
  if (kind === 'weapon' || kind === 'skin') {
    const catalog = kind === 'weapon' ? WEAPONS : SKINS;
    if (!hasOwn(catalog, id)) return fail('Artículo desconocido.');
    item = catalog[id];
    ownedKey = kind === 'weapon' ? 'ownedWeapons' : 'ownedSkins';
    if (next[ownedKey].includes(id)) return fail('Ya tienes este artículo.');
  } else if (kind === 'ammo' && hasOwn(WEAPONS, id)) {
    const weapon = WEAPONS[id];
    if (!next.ownedWeapons.includes(id)) return fail('Primero necesitas esa arma.');
    item = weapon.ammo;
    const cap = item.amount * item.maxPacks;
    if (next.ammo[id] >= cap) return fail(`Munición al máximo para ${weapon.name}.`);
  } else {
    return fail('Artículo desconocido.');
  }
  if (next.credits < item.price) return fail('Créditos insuficientes.');
  next.credits -= item.price;
  if (kind === 'ammo') {
    const cap = item.amount * item.maxPacks;
    next.ammo[id] = Math.min(cap, next.ammo[id] + item.amount);
  } else {
    next[ownedKey].push(id);
    next[kind] = id;
  }
  return { profile: next, ok: true, message: `${item.name || item.label}: compra realizada.` };
}

export function equip(profile, kind, id) {
  const next = normalizeProfile(profile);
  const catalog = kind === 'weapon' ? WEAPONS : kind === 'skin' ? SKINS : null;
  if (!catalog || !hasOwn(catalog, id)) {
    return { profile: next, ok: false, message: 'Artículo desconocido.' };
  }
  const owned = kind === 'weapon' ? next.ownedWeapons : next.ownedSkins;
  if (!owned.includes(id)) {
    return { profile: next, ok: false, message: 'Primero debes comprar este artículo.' };
  }
  next[kind] = id;
  return { profile: next, ok: true, message: `${catalog[id].name}: equipado.` };
}

/** Effective run stats: weapon tension plus skin modifiers, clamped to sane floors. */
export function runStats(weaponId, skinId) {
  const weapon = WEAPONS[weaponId] || WEAPONS.pistol;
  const skin = SKINS[skinId] || SKINS.survivor;
  const modifiers = skin.modifiers || { health: 0, speed: 0, damage: 0 };
  return {
    weapon,
    skin,
    maxHealth: Math.max(40, Math.round(100 + (modifiers.health || 0))),
    speedScale: Math.max(.6, weapon.moveScale * (1 + (modifiers.speed || 0))),
    damageScale: Math.max(.5, 1 + (modifiers.damage || 0)),
  };
}

/**
 * Consumes the purchased rounds for the equipped weapon and reports the
 * magazine plus reserve the run starts with. Purchased ammo is spent, not banked.
 */
export function beginRun(profile, runId) {
  if (!validRunId(runId)) throw new TypeError('Identificador de salida no válido.');
  const next = normalizeProfile(profile);
  const weapon = WEAPONS[next.weapon] || WEAPONS.pistol;
  const bought = next.ammo[weapon.id] || 0;
  next.ammo = { ...next.ammo, [weapon.id]: 0 };
  const reserve = weapon.startReserve + bought;
  const stats = runStats(weapon.id, next.skin);
  return {
    profile: next,
    runId,
    loadout: {
      weapon: weapon.id,
      skin: next.skin,
      extraAmmo: bought,
      reserve,
      magazine: Math.min(weapon.magazine, weapon.magazine + reserve),
      maxHealth: stats.maxHealth,
      speedScale: stats.speedScale,
      damageScale: stats.damageScale,
    },
  };
}

export function rewardExtraction(profile, runId, options = {}) {
  const next = normalizeProfile(profile);
  if (!validRunId(runId)) {
    return { profile: next, awarded: 0, message: 'Identificador de salida no válido.' };
  }
  if (next.completedRuns.includes(runId)) {
    return { profile: next, awarded: 0, message: 'Esta extracción ya fue recompensada.' };
  }
  const supplies = options && typeof options === 'object' &&
    !Array.isArray(options) && options.supplies === true;
  const reward = EXTRACTION_REWARD + (supplies ? SUPPLIES_BONUS : 0);
  const awarded = Math.min(reward, MAX_CREDITS - next.credits);
  next.credits += awarded;
  next.firstRunDone = true;
  // Bounded history is a local duplicate guard, not an anti-cheating ledger.
  next.completedRuns = [...next.completedRuns, runId].slice(-MAX_COMPLETED_RUNS);
  return { profile: next, awarded, message: `Extracción completada: +${awarded} créditos.` };
}

export function loadProfile() {
  try {
    const raw = globalThis.localStorage.getItem(ECONOMY_KEY);
    if (raw !== null) return normalizeProfile(JSON.parse(raw));
    const legacy = globalThis.localStorage.getItem(LEGACY_ECONOMY_KEY);
    if (legacy !== null) return normalizeProfile(JSON.parse(legacy));
    return defaultProfile();
  } catch (_) {
    return defaultProfile();
  }
}

export function saveProfile(profile) {
  try {
    globalThis.localStorage.setItem(ECONOMY_KEY, JSON.stringify(normalizeProfile(profile)));
    return true;
  } catch (_) {
    // Unavailable, blocked or full storage must not prevent playing this session.
    return false;
  }
}
