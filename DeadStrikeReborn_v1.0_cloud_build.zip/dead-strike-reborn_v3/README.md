# Dead Strike Reborn — v1.0 (base: APK real v0.9)

Proyecto reconstruido **a partir del APK compilado**, no del transcript. Todo el
código del juego que hay aquí es el original del build v0.9, extraído byte a byte
del APK y verificado funcionando en navegador.

| | |
|---|---|
| Paquete | `dev.distrito09.game` |
| versionName / versionCode | **1.0 / 13** (árbol de trabajo; el APK base era 0.9 / 12) |
| Origen | `dead-strike-reborn-v0.9.apk` (1.157.581 bytes) |
| SHA-256 del APK | `11fcf3875f23610feb03c1a17d01cd31be22b7b1432b90e4ebf99df9309bde8e` |
| Firma | `CN = Distrito 09 Prototype`, autofirmada, esquemas v2 + v3 |
| Motor | Three.js **r160** vendorizado (MIT) |
| Permisos Android | **ninguno** |

---

## Ejecutar

El juego usa módulos ES, así que necesita servidor HTTP (`file://` no funciona):

```bash
python3 -m http.server 8099
# abrir http://localhost:8099/index.html
```

Para simular el modo móvil del APK (controles táctiles, sombras desactivadas):

```
http://localhost:8099/index.html?touch=1
```

Ese `?touch=1` es exactamente lo que carga el wrapper Android:
`https://appassets.androidplatform.net/assets/index.html?touch=1`.

### Controles de escritorio

`WASD` / flechas mover · arrastrar ratón mirar · `Espacio` disparar ·
`R` recargar · `C` o clic derecho apuntar · `V` empujar · `F` recoger ·
`E`/`Q` girar cámara · `Esc` pausa

## Estructura

```
index.html              UI completa (intro, HUD, pausa, fin)
game.js                 bucle, cámara, render, audio, entrada (824 líneas)
aim-rules.js            pitch −70°/+75°, dirección, rayBox, asistencia de mira
combat-rules.js         tiempos de empuje, recarga, selección de objetivo
economy-rules.js        armas, skins, créditos, perfil persistente
mission-rules.js        misión, recogidas, 36 spawns base
wave-rules.js           3 oleadas de refuerzo, planificación de spawns
character-models.js     fábrica de personajes y zombis low-poly
mission-world.js        geometría del distrito
street-detail.js        detalle procedural de la calle
shop-ui.js / shop.css   tienda del refugio
joystick-editor.js      editor visual de joystick
joystick-settings.js    persistencia del joystick
controls-settings.js    persistencia de sensibilidad
style.css               estilos base
vendor/three.module.js  Three.js r160 + licencia MIT
assets/branding/        iconos 192 y 512
android/res/            recursos del APK (iconos de lanzador)
android/AndroidManifest.binary.xml   manifest original, sin tocar
android/MainActivity.java            RECONSTRUIDO (ver abajo)
build-apk.sh                         RECONSTRUIDO (ver abajo)
docs/REAL_VS_RECONSTRUCTED.md        comparación con la reconstrucción anterior
```

## Qué está verificado

Comprobado con Playwright + Chromium headless, WebGL por software
(`--use-gl=swiftshader`), viewport 1280×720 y también 915×412 con emulación táctil.

| Comprobación | Resultado |
|---|---|
| Sintaxis de los 13 módulos JS | 13/13 OK |
| Assets por HTTP | 200 en todos, incluido Three.js (1.272.972 B) |
| Errores de consola / `pageerror` | **0 y 0** |
| Arranque | `phase: playing`, intro oculta, HUD visible |
| Enemigos | **36 exactos** |
| Munición / reserva inicial | **12 / 18** (30 balas) |
| Caminar con `W` | z 54 → 53,858 (**decrece**: convención −Z correcta) |
| Disparo | cargador 12 → 11, `lastShot.impact: "enemy"` |
| Recarga | `reloadMode: manual`, `reloadTotal: 0.8` |
| Apuntar | `aiming: true`, FOV 58 → 48,75 |
| Pausa | `phase: paused` |
| Cámara | jugador z 53,86 / cámara z 56,13 → **detrás**, tercera persona |
| Render por frame | ~238–243 draw calls, ~17–20 k triángulos |
| Modo `?touch=1` | `touch-device`, joystick 122 px en (0.025, 0.96), controles táctiles `block` |

La escena se revisó además visualmente: avatar low-poly visible de espaldas, HUD
legible sin solapes, niebla y distrito renderizados.

## Lo que el build real tiene y la reconstrucción anterior no tenía

La reconstrucción previa se hizo solo con el transcript del MHTML, que **no contenía
código**: era una reimplementación contra la especificación. El APK real la sustituye
por completo. Diferencias principales:

- **`joystick-editor.js`** (248 líneas) no existía en la reconstrucción: editor visual
  para arrastrar el joystick por pantalla.
- **`controls-settings.js`** (30 líneas) tampoco: normalización y persistencia de
  sensibilidad, que en la reconstrucción estaba incrustada en `game.js`.
- **`game.js` real es 824 líneas frente a 1.471** de la reconstrucción, y el real
  expone el hook de diagnóstico `window.__gameState`.
- **Tabla de enemigos real: 90 / 90 / 180 / 270 HP** (errante, corredor, resistente,
  bruto). La reconstrucción había puesto 100/100/200/300.
- Diferencias de líneas en todos los ficheros: `game.js` 2.067, `character-models.js`
  818, `shop-ui.js` 721, `style.css` 588.

Detalle completo en [`docs/REAL_VS_RECONSTRUCTED.md`](docs/REAL_VS_RECONSTRUCTED.md).

## Qué sigue siendo reconstruido

Estas dos piezas **no son originales** y están marcadas como tales:

### `android/MainActivity.java` — reconstruido

Un APK solo contiene `classes.dex` compilado; el fuente Java no viaja en el paquete.
Este fichero se infiere de las cadenas del dex y reproduce el comportamiento
documentado del wrapper:

- carga `https://appassets.androidplatform.net/assets/index.html?touch=1` vía
  `WebViewAssetLoader` (no `file://`)
- `shouldInterceptRequest` sirve desde `AssetManager` con MIME explícito
  (`text/html`, `text/javascript`, `text/css`, `image/png`, `text/plain`) y
  `Cache-Control: no-cache`
- `setAllowFileAccess` / `setAllowContentAccess` desactivados, `setDomStorageEnabled`
  y `setJavaScriptEnabled` activos
- `onBackPressed` despacha al JS: `distrito-back` en la tienda, `#pause` en juego

**No se puede garantizar que coincida línea a línea con el original.**

### `build-apk.sh` — reconstruido y nunca ejecutado

El script de build no viaja en el APK. La versión incluida envuelve los assets en un
WebView con `aapt` / `javac` / `d8` / `zipalign` / `apksigner`, sin Gradle, coherente
con minSdk 26 / targetSdk 35 y el `versionCode 12` observados. **No se ha ejecutado
nunca contra un SDK de Android real**, así que hay que tratarlo como plantilla.

## Riesgos y rarezas encontrados

- **Dependencia frágil del hook `window.__gameState`.** El Java del APK lo llama como
  función (`window.__gameState().phase`); `game.js` lo asigna a la función `state`,
  así que funciona. Si alguien refactoriza y lo elimina o lo convierte en un objeto,
  el botón atrás de Android deja de responder. No está "arreglado" a propósito:
  es el comportamiento del build real.
- **Sombras desactivadas en táctil.** `renderer.shadowMap.enabled = !touch`. En el
  APK, que siempre es táctil, las sombras nunca se encienden: por eso los objetos
  parecen flotar. En escritorio sin `?touch=1` sí se activan. Es una decisión de
  rendimiento del original, no un fallo de la extracción.
- **Niebla exponencial a 0,0385** con color de fondo `#bdc3bd`: la escena se ve
  lavada a partir de ~40 m. Coincide con la dirección de arte documentada, pero
  también es el motivo de que el distrito parezca plano.
- **Audio sintetizado, no muestreado.** Solo hay `AudioContext` con osciladores
  (`sawtooth` + filtro `lowpass`) y un `createBufferSource`: el sonido es generado,
  no hay ficheros de audio en el APK. Es lo esperado en 1,1 MB de APK.
- **Clave de firma de prototipo.** `CN = Distrito 09 Prototype` es autofirmada y su
  huella SHA-256 está publicada en `docs/REAL_VS_RECONSTRUCTED.md`. No sirve para
  Play y no debe reutilizarse para una release.

## v1.0 — qué cambió sobre el APK v0.9

Diez mejoras implementadas sobre el árbol real, sin tocar el original. Todo lo de
abajo está verificado por `tests/verify.py` (39/39 comprobaciones en Chromium headless).

### 1. Audio procedural (`audio-engine.js`)

Fuera los osciladores de onda cuadrada. Todo se sintetiza en un `AudioContext`:
ruido filtrado para el cuerpo de cada disparo, un `ConvolverNode` con impulso de
ruido decreciente para la reverb corta de calle, y `StereoPannerNode` por voz.

| Sonido | Síntesis |
|---|---|
| Disparo | burst lowpass (cuerpo por arma) + triángulo grave (retumbe) |
| Impacto | lowpass corto en carne / highpass en mundo + seno descendente |
| Recarga | tres clics bandpass (cargador fuera, dentro, corredera) |
| Pasos | lowpass 700→180 Hz, más suave al apuntar |
| Ambiente | retumbe <120 Hz + viento bandpass 620 Hz con LFO a 0,07 Hz |
| Gruñido | sierra 58→36 Hz, paneado por posición relativa al jugador |

El paneo de zombis usa `panFor()`: proyecta el vector enemigo sobre el eje derecho
de la cámara, así que **un gruñido por detrás se oye por detrás**.

### 2. Blob shadows (`feedback.js`)

Plano con textura radial (`CanvasTexture` 128×128, degradado de 0,72 a 0) bajo cada
personaje y enemigo, con `polygonOffset` para no pelear con el asfalto. **37 sombras
activas** (jugador + 36 enemigos), también en táctil. El shadow map completo sigue
apagado en táctil: `renderer.shadowMap.enabled = !touch`.

### 3. Feedback de impacto

Hitmarker de cuatro ticks (ámbar al matar), número de daño flotante proyectado a
pantalla, flash blanco de un frame en el enemigo golpeado (`emissive`), y
micro-sacudida de cámara de 2–3 px con decaimiento de 0,18 s.

### 4. Oleadas escalonadas

Cada oleada introduce **un** arquetipo y conserva los anteriores como relleno:

| Oleada | Añade | Composición |
|---|---|---|
| 1 | Errante | 4 errantes |
| 2 | Corredor | 2 errantes + 2 corredores |
| 3 | Resistente | 1 corredor + 2 resistentes + 1 errante |
| 4 | Bruto blindado | 2 resistentes + 1 bruto + 1 corredor |

### 5. Economía más dura

| Concepto | v0.9 | v1.0 |
|---|---|---|
| Recompensa por escape | 60 cr | **35 cr** |
| Bonus de suministros | +20 cr | **+15 cr** |
| Revólver R-6 | 150 cr | **320 cr** |
| Skin Renacida | 110 cr | **420 cr** |

### 6. Armas nuevas y munición por arma

| Arma | Precio | Cargador | Daño | Cadencia | Reserva inicial | Munición (precio · cantidad · tope) |
|---|---|---|---|---|---|---|
| Pistola 9 mm | 0 | 12 | 45 | 0,29 s | 18 | 14 cr · 12 · 3 cajas |
| Revólver R-6 | 320 | 6 | 90 | 0,60 s | 0 | 22 cr · 12 · 3 cajas |
| Vípera MP-9 | 480 | 24 | 28 | 0,11 s | 0 | 26 cr · 36 · 3 cargadores |
| Quiebra-12 | 620 | 5 | 26 ×6 perdigones | 0,78 s | 0 | 30 cr · 15 · 3 cajas |
| Cerraja-7 | 780 | 8 | 120 | 0,85 s | 0 | 34 cr · 16 · 3 peines |

La munición se compra **por arma**, con su propio tope y su propio stock persistente.
Lo comprado se consume al empezar la salida (`beginRun`), no se acumula como banco.

### 7. Skins con tensión

| Skin | Precio | Modificadores |
|---|---|---|
| Superviviente | 0 | — (referencia) |
| Guardia carmesí | 180 | +20 vitales, −4% velocidad |
| Exploradora | 240 | +9% velocidad, −10 vitales |
| Chatarrera | 300 | +12% daño, −6% velocidad |
| Renacida | 420 | **+15% velocidad, −25 vitales** |

Las armas también pesan: `moveScale` va de 1,00 (pistola) a 0,82 (Cerraja-7), así que
la elección nunca es obvia.

### 8. Persistencia real

`localStorage` bajo `distrito09.profile.v2`, con migración desde `v1` (el contador
`ammoPacks` se convierte en balas de pistola). Guarda créditos, armas, munición por
arma, skins, arma y skin equipadas, y el historial de salidas. Verificado cerrando y
reabriendo: recarga de página **y** contexto de navegador nuevo.

### 9. Editor de joystick en el primer arranque

En táctil, si el perfil no tiene ninguna salida completada, el editor se abre solo
sobre la intro ("coloca tus controles"). En escritorio no aparece: no hay joystick
que colocar.

### 10. Bifurcación de ruta

| Ruta | Peligro | Enemigos | Suministros |
|---|---|---|---|
| Corta (avenida directa) | ALTA | +6 infectados | ninguno |
| Larga (desvío por la clínica) | MEDIA | base | +15 cr al escapar, +6 balas y +15 vitales en el alijo |

Se elige una sola vez, en la bifurcación (z ≈ 8), y no hay vuelta atrás.

### Verificación

```bash
python3 -m http.server 8099 &
python3 tests/verify.py     # 39/39
```

Cubre: arranque sin errores de consola ni peticiones fallidas, 36 enemigos, 12/18 de
munición inicial, caminar, apuntar (FOV 58→44), disparo con impacto real, feedback
visual, compra de arma + munición + skin por la UI, persistencia tras recarga,
bifurcación de ruta, tensión de skin, escalado de oleadas, y una segunda sesión
móvil con sombras blob y shadow map apagado.

> Nota: con GL por software el reloj avanza ~45× más lento que en tiempo real, así
> que el arnés usa `?debug=1` (`__debugAdvance`, `__debugTeleport`) para mover la
> simulación de forma determinista. Esos hooks no existen sin el parámetro.

## Camino a v1.1

Los diez puntos de la lista anterior ya están hechos (ver la sección v1.0). Lo que
queda es lo que **no se puede hacer en un sandbox**:

### Bloqueantes

1. **Compilar un APK con este árbol.** `build-apk.sh` sigue sin ejecutarse contra un
   SDK real. Es la única pieza del proyecto que nunca ha tocado un compilador.
2. **Instalar en hardware físico.** Todo lo verificado aquí es Chromium headless con
   GL por software. Falta un Android real (el objetivo original era un Samsung A37,
   Android 17) para medir el coste real de las 37 blob shadows y del audio procedural.
3. **Regenerar una clave de firma propia.** La actual es de prototipo y su huella ya
   está publicada en `docs/REAL_VS_RECONSTRUCTED.md`.

### Pulido

4. Medir draw calls con las blob shadows activas en un dispositivo de gama media; si
   pesan, agruparlas en un solo `InstancedMesh`.
5. Revisar la densidad de niebla (0,0385) para recuperar profundidad sin perder la
   atmósfera.
6. Subir el tamaño del texto de la leyenda de controles en escritorio.

### Mantenimiento

7. Ampliar `tests/verify.py` con asserts puros de `aim-rules` y `combat-rules` (los
   de economía, misión y oleadas ya están cubiertos de forma indirecta).
8. Documentar el contrato de `window.__gameState` para que el wrapper Android y el JS
   no se desincronicen: el Java del APK lo invoca como función.
9. Añadir `.gitignore` y fijar la versión de Three.js si se actualiza.

## Licencias

Three.js r160 bajo licencia MIT (`vendor/THREE-LICENSE.txt`). El resto del código es
del proyecto original. "Dead Strike Reborn" se declara **prototipo no oficial** en la
propia UI; el nombre "Dead Strike" pertenece a su autor original y este proyecto no
está afiliado a él.

## Compilar APK en GitHub Actions (sin instalar Android SDK en tu celular)

El archivo `.github/workflows/build-apk.yml` permite ejecutar la compilación en un runner de GitHub con Java 17 y Android SDK 35. Sube el contenido de esta carpeta a un repositorio de GitHub; luego abre **Actions → Build Dead Strike Reborn APK → Run workflow**. Cuando termine correctamente, abre la ejecución y descarga **dead-strike-reborn-apk** en la sección **Artifacts**. La clave de firma se genera temporalmente en cada ejecución; si recompilas, Android puede no permitir instalar encima de una versión firmada con otra clave: desinstala la anterior primero o configura una clave persistente propia.

Este flujo de trabajo se ha preparado, pero aún no se ha ejecutado en GitHub; el APK solo estará disponible si la ejecución termina en verde.
