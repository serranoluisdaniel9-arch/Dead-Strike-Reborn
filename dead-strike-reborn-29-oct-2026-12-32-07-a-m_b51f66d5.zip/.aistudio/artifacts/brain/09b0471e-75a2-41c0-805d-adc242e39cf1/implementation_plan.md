# Dead Strike Reborn — Modernización Gráfica, Nuevo Arsenal y Sistema de Accesorios

Plan integral para modernizar y potenciar el videojuego 3D *Dead Strike Reborn* (Three.js), implementando mejoras gráficas cinematográficas (iluminación dinámica, sombras suaves, partículas avanzadas y niebla atmosférica), expandiendo el arsenal con tres nuevas categorías de armas (Fusil de Asalto, Francotirador y Lanzallamas), e incorporando un sistema de accesorios y mejoras en la tienda del refugio.

## Decisiones Críticas y Revisión del Usuario

> [!IMPORTANT]
> Decisiones confirmadas según las elecciones del usuario:
> - **Mejora Visual Completa**: Se implementará el paquete integral de gráficos:
>   1. Iluminación dinámica solar y nocturna con sombras suaves (`PCFSoftShadowMap`).
>   2. Niebla atmosférica volumétrica y profundidad ambiental.
>   3. Sistema de partículas para destellos de disparo (*muzzle flash* luminoso reactivo), chispas de impacto, salpicaduras de sangre y llamaradas continuas.
>   4. Materiales PBR optimizados con mapas de rugosidad y metalicidad en armas y personajes.
> - **Nuevas Armas al Arsenal**:
>   1. **Fusil de Asalto 'Furia M4' / 'Vindicator 5.56'**: Fuego automático rápido, cargador de 30 balas, gran versatilidad a media distancia.
>   2. **Rifle de Francotirador 'Ojo de Halcón 7.62'**: Daño crítico letal, disparo de largo alcance y modo de puntería con retícula de francotirador.
>   3. **Lanzallamas 'Infierno Napalm'**: Disparo continuo en cono de fuego con física de partículas ígneas y daño por quemadura residual (*Damage over Time*) a grupos de zombis.
> - **Sistema de Accesorios y Mejoras en la Tienda**:
>   - Nueva sección en el refugio para instalar modificaciones a las armas adquiridas:
>     - **Cargador Ampliado**: Aumenta la capacidad del cargador (+30% a +50%).
>     - **Freno de Boca / Compensador**: Reduce el retroceso en disparo continuo.
>     - **Cañón Pesado**: Incrementa el daño base por proyectil.
>     - **Mecanismo Táctico**: Reduce el tiempo de recarga.
>     - **Miras Ópticas**: Mejora la precisión y amplía el campo de visión al apuntar (*ADS*).

---

## 1. Visión General y Concepto Central

- **Propósito**: Elevar *Dead Strike Reborn* desde su base actual a un shooter de supervivencia 3D de alta fidelidad, con una atmósfera postapocalíptica envolvente, combate visceral y una economía táctica profunda donde el jugador personaliza su equipamiento antes de cada incursión en el distrito infectado.
- **Audiencia objetivo**: Jugadores tanto de PC (controles con teclado `WASD`, espacio, `R`, clic derecho para apuntar) como de móviles y tablets (joystick táctil virtual y botones ergonómicos).
- **Valor agregado**: Combate mucho más satisfactorio gracias a la respuesta visual y sonora de los disparos, mayor rejugabilidad por la variedad de armas pesadas y automáticas, y un ciclo de progresión adictivo mediante accesorios de armería.

---

## 2. Experiencia de Usuario y Diseño Visual

### Iluminación, Sombras y Atmósfera
- **Iluminación Principal**:
  - `DirectionalLight` simulando luz lunar/crepuscular con sombras proyectadas nítidas sobre personajes, zombis y barricadas.
  - `HemisphereLight` para contraste de color frío cielo / cálido suelo urbano.
  - `PointLight` dinámica vinculada al *muzzle flash* de cada arma, que ilumina instantáneamente al jugador y las paredes cercanas al disparar.
  - Linterna del jugador (`SpotLight`) con haz cónico suave para zonas oscuras.
- **Niebla y Clima**:
  - `scene.fog = new THREE.FogExp2('#141c24', 0.028)` para fundir el horizonte urbano con la noche y crear tensión psicológica ante zombis que emergen de la oscuridad.
  - Efecto de polvo flotante o llovizna ligera opcional activable sin coste excesivo de GPU.

### Sistema de Partículas y Efectos de Combate
- **Impacto y Sangre**: Salpicaduras de sangre direccionales cuando las balas impactan en zombis, y chispas al chocar con metal/cemento.
- **Fuego del Lanzallamas**: Sistema de partículas `THREE.Points` o sprites de fuego que avanzan en cono, cambian de color (amarillo brillante $\to$ naranja $\to$ humo gris) e infligen combustión a los enemigos alcanzados.
- **Retícula de Francotirador**: Al activar la mira (`C` o clic derecho) con el francotirador, la cámara hace zoom óptico (`FOV` reducido) y se despliega una retícula de francotirador con telemetría milimétrica.

### Interfaz de Usuario y Tienda del Refugio
- **Tienda Renovada**:
  - Pestañas claras: *Armas*, *Accesorios & Mejoras*, *Atuendos / Skins* y *Suministros*.
  - Vista previa 3D o esquemática con estadísticas comparativas (Daño, Cadencia, Alcance, Capacidad, Movilidad).
  - Indicador visual de accesorios instalados en cada arma.
- **HUD Durante la Partida**:
  - Barra de salud con color de estado claro.
  - Indicador de arma activa, munición actual / reserva y accesorio equipado.
  - Botón de pausa accesible y avisos de oleadas de refuerzo con tipografía nítida y legible.

---

## 3. Decisiones Técnicas y de Producto

### Especificaciones del Arsenal
| Arma | Tipo | Daño | Cadencia | Capacidad | Alcance | Retroceso | Característica Especial |
|---|---|---|---|---|---|---|---|
| **Pistola 9 mm** | Secundaria | 45 | 0.29s | 12 | 30m | Bajo | Rápida y económica |
| **Revólver R-6** | Potente | 90 | 0.60s | 6 | 25m | Alto | Alto poder de parada |
| **Vípera MP-9** | Subfusil | 28 | 0.11s | 24 | 24m | Medio | Alta cadencia a corta distancia |
| **Quiebra-12** | Escopeta | 26 x 6 | 0.78s | 5 | 16m | Alto | Dispersión de 6 perdigones |
| **Cerraja-7** | Fusil | 120 | 0.85s | 8 | 46m | Medio | Precisión media-larga |
| **Furia M4** *(Nueva)* | Asalto | 52 | 0.095s | 30 | 42m | Medio-Bajo | Automática, ráfagas estables |
| **Ojo de Halcón** *(Nueva)* | Sniper | 320 | 1.25s | 5 | 75m | Muy Alto | Zoom óptico, muerte instantánea |
| **Infierno Napalm** *(Nueva)* | Pesada | 22/tick | 0.06s | 60 | 14m | Mínimo | Cono continuo de fuego + DoT |

### Sistema de Mejoras (Upgrades)
- Estructura de datos en `economy-rules.js`:
  ```typescript
  type WeaponAttachment = 'mag_ext' | 'recoil_comp' | 'heavy_barrel' | 'fast_loader' | 'holo_sight';
  ```
- Cada arma puede equipar hasta 2 accesorios simultáneos que modifican multiplicativamente sus atributos en tiempo de ejecución.
- Guardado y persistencia en `localStorage` bajo el perfil del jugador.

### Renderizado y Optimización
- Detección de `isSoftwareGl` (entornos headless/baja potencia) para ajustar resolución de sombras y tasa de partículas, asegurando 60 FPS estables en cualquier dispositivo.
- Reutilización de vectores y matrices matemáticas (`Vector3`, `Matrix4`) fuera de los bucles de render para evitar recolector de basura (*zero GC pressure*).

---

## 4. Arquitectura del Sistema

```
┌────────────────────────────────────────────────────────┐
│             App Shell (React 19 + Three.js)            │
│  - Canvas Mount Lifecycle                              │
│  - Touch / Desktop Input Controller                    │
└──────────────────────────┬─────────────────────────────┘
                           │
             ┌─────────────┴─────────────┐
             ▼                           ▼
┌──────────────────────────┐   ┌─────────────────────────┐
│     Economy & Store      │   │   Three.js 3D Engine    │
│ - Weapons (8 Archetypes) │   │ - PBR Shaders & Lights  │
│ - Attachments & Upgrades │   │ - Soft Shadow Pipeline  │
│ - Persistence (Storage)  │   │ - Volumetric Mist & Sky │
└────────────┬─────────────┘   └─────────────┬───────────┘
             │                               │
             ▼                               ▼
┌──────────────────────────┐   ┌─────────────────────────┐
│       Game Loop          │   │     VFX & Particles     │
│ - Wave Director          │◄──┤ - Muzzle Flares (Light) │
│ - AI Zombie Spawner      │   │ - Flame Cone Physics    │
│ - Raycast Combat Engine  │   │ - Blood & Decal Splats  │
└──────────────────────────┘   └─────────────────────────┘
```
