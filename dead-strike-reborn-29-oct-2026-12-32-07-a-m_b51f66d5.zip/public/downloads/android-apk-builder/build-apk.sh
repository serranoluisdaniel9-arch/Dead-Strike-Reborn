#!/usr/bin/env bash
#
# build-apk.sh — RECONSTRUCTED BUILD SCRIPT.
#
# The snapshot documents the toolchain and one hard-won packaging detail, but the
# script's own text never appeared in the transcript. Reproduced from the spec:
#   aapt -> javac -> d8 -> zipalign 4 -> apksigner, signatures v2 + v3,
#   versionName/versionCode read from AndroidManifest.xml,
#   resources.arsc stored UNCOMPRESSED (ZIP_STORED) before zipalign, which is
#   what made the very first install succeed,
#   keystore outside the repo at ~/.android/distrito09-prototype.keystore.
#
# Requires: Android SDK build-tools 35, platform android-35, JDK 17.
# This script is NOT known to have been run successfully for v0.9 — the final
# export in the original session was cut off by LLM credit exhaustion.

set -euo pipefail

# ---------------------------------------------------------------- configuration

SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/android-sdk}}"
BUILD_TOOLS="${BUILD_TOOLS:-$SDK_ROOT/build-tools/35.0.0}"
PLATFORM="${PLATFORM:-$SDK_ROOT/platforms/android-35/android.jar}"

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
MANIFEST="$PROJECT_DIR/android/AndroidManifest.xml"
KEYSTORE="${KEYSTORE:-$HOME/.android/distrito09-prototype.keystore}"
KEY_ALIAS="${KEY_ALIAS:-distrito09}"
KEY_PASS="${KEY_PASS:-}"     # never hard-coded: export it, or the script prompts
OUT_DIR="$PROJECT_DIR/downloads"

# ---------------------------------------------------------------- sanity checks

require() {
  if [ ! -e "$1" ]; then
    echo "ERROR: missing $2 at $1" >&2
    exit 1
  fi
}

require "$BUILD_TOOLS/aapt"    "aapt (build-tools)"
require "$BUILD_TOOLS/d8"      "d8 (build-tools)"
require "$BUILD_TOOLS/zipalign" "zipalign (build-tools)"
require "$BUILD_TOOLS/apksigner" "apksigner (build-tools)"
require "$PLATFORM"            "android.jar (platform 35)"
require "$MANIFEST"            "AndroidManifest.xml"

if [ -z "$KEY_PASS" ]; then
  read -r -s -p "keystore password: " KEY_PASS
  echo
fi

# ---------------------------------------------------------- version from manifest

VERSION_NAME=$(grep -o 'android:versionName="[^"]*"' "$MANIFEST" | head -1 | sed 's/.*="//; s/"$//')
VERSION_CODE=$(grep -o 'android:versionCode="[^"]*"' "$MANIFEST" | head -1 | sed 's/.*="//; s/"$//')

if [ -z "$VERSION_NAME" ] || [ -z "$VERSION_CODE" ]; then
  echo "ERROR: could not read versionName/versionCode from the manifest" >&2
  exit 1
fi

APK_NAME="dead-strike-reborn-v${VERSION_NAME}.apk"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

mkdir -p "$OUT_DIR"
echo "==> building $APK_NAME (versionCode $VERSION_CODE)"

# ------------------------------------------------------------- 1. assets payload

STAGE="$WORK/stage"
mkdir -p "$STAGE/assets"

# Game payload: everything the WebView serves from /assets/.
for f in index.html style.css joystick.css shop.css game.js; do
  require "$PROJECT_DIR/$f" "game file $f"
  cp "$PROJECT_DIR/$f" "$STAGE/assets/"
done
cp "$PROJECT_DIR"/*-rules.js "$STAGE/assets/"
cp "$PROJECT_DIR/street-detail.js"     "$STAGE/assets/"
cp "$PROJECT_DIR/mission-world.js"     "$STAGE/assets/"
cp "$PROJECT_DIR/character-models.js"  "$STAGE/assets/"
cp "$PROJECT_DIR/shop-ui.js"           "$STAGE/assets/"
cp "$PROJECT_DIR/joystick-settings.js" "$STAGE/assets/"
mkdir -p "$STAGE/assets/vendor" "$STAGE/assets/assets"
cp "$PROJECT_DIR/vendor/three.module.js" "$STAGE/assets/vendor/"
cp "$PROJECT_DIR/assets/icon.svg"        "$STAGE/assets/assets/"

# ------------------------------------------------------- 2. resources (aapt)

aapt package -f -m \
  -J "$WORK/gen" \
  -M "$MANIFEST" \
  -S "$PROJECT_DIR/android/res" \
  -A "$STAGE/assets" \
  -I "$PLATFORM" \
  -F "$WORK/base.apk"

# ------------------------------------------------------------ 3. R.java + javac

mkdir -p "$WORK/classes"
javac -source 17 -target 17 \
  -bootclasspath "$PLATFORM" \
  -classpath "$PLATFORM" \
  -d "$WORK/classes" \
  "$PROJECT_DIR/android/MainActivity.java" \
  $(find "$WORK/gen" -name '*.java' 2>/dev/null || true)

# ------------------------------------------------------------------- 4. d8

mkdir -p "$WORK/dex"
d8 --release --min-api 26 \
  --lib "$PLATFORM" \
  --output "$WORK/dex" \
  $(find "$WORK/classes" -name '*.class')

# ------------------------------------------------- 5. repack with classes.dex

# resources.arsc MUST stay uncompressed or the install fails.
cd "$WORK"
cp base.apk unsigned.apk
( cd "$WORK/dex" && zip -q -X "$WORK/unsigned.apk" classes.dex )

echo "==> forcing resources.arsc to ZIP_STORED"
python3 - "$WORK/unsigned.apk" <<'PY'
import shutil, sys, zipfile

path = sys.argv[1]
tmp = path + '.rebuilt'
with zipfile.ZipFile(path, 'r') as src, zipfile.ZipFile(tmp, 'w') as dst:
    for item in src.infolist():
        data = src.read(item.filename)
        if item.filename == 'resources.arsc':
            info = zipfile.ZipInfo(item.filename)
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = item.external_attr
            dst.writestr(info, data)
        else:
            dst.writestr(item, data)
shutil.move(tmp, path)
PY

# ------------------------------------------------------ 6. zipalign + apksigner

"$BUILD_TOOLS/zipalign" -f -p 4 "$WORK/unsigned.apk" "$WORK/aligned.apk"

"$BUILD_TOOLS/apksigner" sign \
  --ks "$KEYSTORE" \
  --ks-key-alias "$KEY_ALIAS" \
  --ks-pass "pass:$KEY_PASS" \
  --v2-signing-enabled true \
  --v3-signing-enabled true \
  --out "$OUT_DIR/$APK_NAME" \
  "$WORK/aligned.apk"

"$BUILD_TOOLS/apksigner" verify --print-certs "$OUT_DIR/$APK_NAME" || true

# The .idsig sidecar is an artefact of v4 signing; never ship it.
rm -f "$OUT_DIR/$APK_NAME.idsig"

echo ""
echo "==> $OUT_DIR/$APK_NAME"
ls -lh "$OUT_DIR/$APK_NAME"
