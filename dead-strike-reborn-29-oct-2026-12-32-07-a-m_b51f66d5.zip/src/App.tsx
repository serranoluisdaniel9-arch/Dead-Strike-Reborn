import { useEffect } from 'react';
import './game/style.css';
import './game/shop.css';
import './game/joystick.css';

export default function App() {
  useEffect(() => {
    // Dynamic import initializes the 3D scene, audio, and gameplay tickers
    import('./game/game.js');
  }, []);

  return (
    <main id="app" className="relative w-full h-full overflow-hidden select-none bg-black">
      <canvas id="game" tabIndex={0} aria-label="Vista 3D de Dead Strike Reborn"></canvas>
      <div className="screen-texture" aria-hidden="true"></div>
      <div id="damage" aria-hidden="true"></div>

      {/* Cinematic fade-in overlay */}
      <div id="fade-overlay" aria-hidden="true"></div>

      {/* Sniper scope overlay with crosshair markings */}
      <div id="sniper-scope" aria-hidden="true">
        <div className="sniper-crosshair">
          <div className="sniper-line-h"></div>
          <div className="sniper-line-v"></div>
          <div className="sniper-ring"></div>
          <div className="sniper-tag">OJO DE HALCÓN · 7.62 TÁCTICO</div>
        </div>
      </div>

      {/* Authentic Dead Strike Retro Monospaced Top-Right HUD */}
      <div id="classic-retro-hud" aria-hidden="true">
        <div id="classic-ammo" className="classic-ammo-line">12/36 : Handgun 9 Cal</div>
        <div id="classic-energy" className="classic-energy-line">100/100 : Energy</div>
      </div>

      {/* Retro Top-Left Calculator / Inventory Button */}
      <button id="classic-calc" className="classic-top-left-calc" aria-label="Abrir Refugio y Tienda" title="Refugio y Tienda">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="22" height="22" aria-hidden="true">
          <rect x="4" y="2" width="16" height="20" rx="2" />
          <line x1="8" y1="6" x2="16" y2="6" />
          <line x1="8" y1="10" x2="10" y2="10" />
          <line x1="14" y1="10" x2="16" y2="10" />
          <line x1="8" y1="14" x2="10" y2="14" />
          <line x1="14" y1="14" x2="16" y2="14" />
          <line x1="8" y1="18" x2="10" y2="18" />
          <line x1="14" y1="18" x2="16" y2="18" />
        </svg>
      </button>

      {/* Intro Overlay */}
      <section id="intro" className="overlay intro" aria-label="Menú principal de Dead Strike Reborn">
        <header className="intro-header">
          <a href="#" className="wordmark" tabIndex={-1}>
            <img src="/assets/branding/icon-192.png" alt="Icono de Dead Strike" className="brand-icon" />
            <span>DEAD STRIKE <span className="wordmark-number">REBORN</span></span>
          </a>
          <span className="network-label"><i></i> SUPERVIVENCIA ZOMBI EN TIEMPO REAL</span>
        </header>

        <div className="intro-content">
          <span className="eyebrow"><span className="short-line"></span> BROTE URBANO · DISTRITO 09</span>
          <h1 className="game-title">
            DEAD STRIKE
            <span className="game-title-reborn">REBORN<span className="title-dot">.</span></span>
          </h1>
          <div className="mission-title">
            <span className="mission-index">OPERACIÓN 01</span>
            <h2>Escape de la Avenida Sur</h2>
          </div>
          <p className="intro-description">
            Cruza la niebla, administra tu munición y neutraliza a los infectados antes de que te rodeen.
            Recarga antes de agotar el cargador para recargar en la mitad de tiempo, o utiliza el botón 180° para vigilar tu espalda.
          </p>

          <div className="intro-cta">
            <button id="start" className="primary-button" disabled>
              <span>INICIAR ESCAPE</span>
              <span aria-hidden="true">↗</span>
            </button>
            <button id="intro-continue" className="refuge-button" style={{ borderColor: 'var(--amber)', color: 'var(--amber)' }} title="Entrar a la tienda de mejoras">
              <strong>CONTINUAR</strong>
              <span>TIENDA / REFUGIO</span>
            </button>
            <button id="intro-shop" className="refuge-button" title="Accesorios y Arsenal">
              <strong><span id="wallet-value">0</span> CR</strong>
              <span>ARMAS Y EQUIPO</span>
            </button>
            <a
              id="download-apk"
              href="/DeadStrikeReborn-v3.0.apk"
              download="DeadStrikeReborn-v3.0.apk"
              className="refuge-button apk-badge-button"
              style={{ borderColor: '#22c55e', color: '#4ade80', textDecoration: 'none', display: 'inline-flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}
              title="Descargar instalador APK directo para Android"
            >
              <strong>DESCARGAR APK</strong>
              <span>ANDROID 3.0 (.APK)</span>
            </a>
          </div>

          <div className="loadout-summary">
            <span id="loadout-summary">Cargando arsenal y mejoras…</span>
            <div id="profile-save-note" className="save-warning hidden">Progreso en memoria (almacenamiento local restringido)</div>
          </div>

          <div className="loading" role="status" aria-live="polite">
            <span className="loading-dot"></span>
            <span id="loading">Preparando motor 3D y niebla…</span>
          </div>

          <div className="intro-controls desktop-hint">
            <span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> Mover</span>
            <span><kbd>Espacio</kbd> Disparar</span>
            <span><kbd>C</kbd> Apuntar</span>
            <span><kbd>X</kbd> Giro 180°</span>
            <span><kbd>Z</kbd> Sigilo</span>
            <span><kbd>T</kbd> Cámara FPS</span>
            <span><kbd>V</kbd> Empujar</span>
            <span><kbd>R</kbd> Recargar</span>
            <span><kbd>F</kbd> Recoger</span>
          </div>
        </div>

        <aside className="sector-label" aria-hidden="true">
          <span className="sector-cross">+</span>
          <div>SECTOR 9-B<span>AVENIDA PRINCIPAL</span></div>
        </aside>

        <aside className="intro-scene-note" aria-hidden="true">
          <span className="live-indicator"></span>
          <div>MOTOR 3D<span>60 FPS RENDER</span><span className="scene-line"></span></div>
        </aside>

        <footer className="intro-footer">
          <span className="landscape-tip">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="6" width="18" height="12" rx="2" /><path d="M7 12h10" /></svg>
            OPTIMIZADO PARA PANTALLA TÁCTIL Y DESKTOP <span className="footer-divider">/</span> AURICULARES RECOMENDADOS
          </span>
          <span className="footer-code">DSR—PROYECTO COMPLETO v3.0</span>
        </footer>
      </section>

      {/* In-Game Modern HUD */}
      <section id="hud" className="hud hidden" aria-label="Estado y controles del juego">
        <div className="hud-top">
          <div className="mission-hud">
            <div className="hud-brand">DS<span>R</span><span className="hud-live">REBORN</span></div>
            <div className="objective-label">OBJETIVO DE ESCAPE</div>
            <p id="objective">Alcanza la zona de extracción</p>
            <div className="mission-nav">
              <span id="mission-arrow" aria-hidden="true">↑</span>
              <strong id="mission-distance">137 m</strong>
              <span id="mission-danger">AVANZA CON CUIDADO</span>
            </div>

            <div className="health-panel">
              <div className="health-heading">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 3h4v7h7v4h-7v7h-4v-7H3v-4h7z" /></svg>
                <span>VITALES</span>
                <strong><span id="health">100</span><small id="health-max"> / 100</small></strong>
              </div>
              <div className="health-track">
                <div id="health-bar"></div>
              </div>
              <span className="health-caption">MANTENTE EN MOVIMIENTO</span>
            </div>
          </div>

          <div className="wave-panel">
            <div className="wave-stat">
              <span className="stat-label">CRÉDITOS</span>
              <strong id="wave">0</strong>
            </div>
            <div className="kill-stat">
              <span className="stat-label">ELIMINADOS</span>
              <strong id="kills">0</strong>
            </div>
            <div id="wave-status" className="wave-progress">
              <span id="wave-label">OLEADAS</span>
              <strong id="wave-count">0/3</strong>
            </div>
          </div>

          <div className="utility-buttons">
            <button id="btn-env" className="env-badge" title="Alternar clima (Día, Noche, Lluvia)">
              <span id="env-badge">CLIMA: NOCHE</span>
            </button>
            <button id="btn-cam" className="icon-button cam-button" aria-label="Cambiar entre cámara FPS y 3ra persona" title="Cámara FPS / 3ra Persona">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" /><circle cx="12" cy="13" r="4" /></svg>
            </button>
            <button id="settings" className="icon-button" aria-label="Ajustar controles y joystick" title="Controles y joystick">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 17h16M8 4v6M16 14v6" /></svg>
            </button>
            <button id="sound" className="icon-button" aria-label="Activar o silenciar sonido" title="Sonido">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5L6 9H3v6h3l5 4V5zM15 8c3 2 3 6 0 8M18 5c5 4 5 10 0 14" /></svg>
            </button>
            <button id="fullscreen" className="icon-button" aria-label="Pantalla completa" title="Pantalla completa">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M21 16v5h-5M8 21H3v-5" /></svg>
            </button>
            <button id="pause" className="icon-button" aria-label="Pausar juego" title="Pausar">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14M16 5v14" /></svg>
            </button>
          </div>
        </div>

        <div id="crosshair" aria-hidden="true"><span></span></div>

        <button id="interact" className="interact-button hidden">
          <kbd className="desktop-hint">F</kbd>
          <span id="interact-label">Recoger</span>
          <span aria-hidden="true">↗</span>
        </button>

        <div id="status" className="status-toast" role="status" aria-live="polite"></div>

        {/* Authentic 180 Turnaround Button */}
        <button id="btn-180" className="turn-180-btn" aria-label="Giro 180 grados rápido" title="Girar 180°">
          180
        </button>

        <div className="hud-bottom">
          <div className="ammo-panel">
            <span className="weapon-label">
              <b id="weapon-name">Pistola 9 mm</b> <span>AHORRA MUNICIÓN</span>
            </span>
            <div className="ammo-count">
              <strong id="ammo">12</strong><span>/</span><span id="reserve">018</span>
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 21V7l4-5 4 5v14H8zM8 16h8" /></svg>
            </div>
            <span id="reload-feedback" className="combat-status">RECARGA ANTES DE VACIAR</span>
            <span className="reload-hint desktop-hint"><kbd>R</kbd> RECARGAR</span>
          </div>
        </div>

        {/* Touch & Combat Action Controls */}
        <div className="touch-controls">
          <div id="joystick" aria-label="Joystick de movimiento">
            <div className="joystick-ring" aria-hidden="true"></div>
            <div id="stick"></div>
            <span className="joystick-label">MOVER</span>
          </div>

          <div className="touch-actions">
            <button id="btn-crouch" className="crouch-button" aria-label="Agacharse para sigilo silencioso" title="Agacharse / Sigilo">
              <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M12 4a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm2 7.5l2-2.5V5h-2v3l-2.5 1.5L9 8v4l3 2v6h2v-6.5l-2-2z"/>
              </svg>
              <span>SIGILO</span>
            </button>

            <button id="aim" className="aim-button" aria-label="Activar apuntado" aria-pressed="false">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M8 3H3v5M16 3h5v5M21 16v5h-5M8 21H3v-5" /><circle cx="12" cy="12" r="4" /><path d="M12 10v4M10 12h4" />
              </svg>
              <span id="aim-label">APUNTAR</span>
            </button>

            <button id="shove" className="shove-button" aria-label="Empujar al infectado de delante">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 16v-4a1 1 0 0 1 2 0V6a1 1 0 0 1 2 0v5-7a1 1 0 0 1 2 0v7-6a1 1 0 0 1 2 0v6-4a1 1 0 0 1 2 0v6l2-2a1 1 0 0 1 2 2l-4 6H9l-4-3z" />
              </svg>
              <span id="shove-label">EMPUJAR</span>
            </button>

            <button id="reload" className="reload-button" aria-label="Recargar arma">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M20 8a8 8 0 1 0 0 8M20 3v6h-6" />
              </svg>
              <span>RECARGAR</span>
            </button>

            <button id="fire" className="fire-button" aria-label="Disparar arma">
              <svg viewBox="0 0 36 36" aria-hidden="true">
                <circle cx="18" cy="18" r="10" /><circle cx="18" cy="18" r="3" /><path d="M18 2v8M18 26v8M2 18h8M26 18h8" />
              </svg>
              <span>FUEGO</span>
            </button>
          </div>
        </div>

        <span className="game-footer desktop-hint">
          WASD · MOVER <span>ARRASTRAR · MIRAR</span> ESPACIO / CLIC · DISPARO RÁPIDO · C · APUNTAR · X · GIRO 180° · Z · SIGILO · T · CÁMARA · V · EMPUJAR · F · RECOGER
        </span>
      </section>

      {/* Pause & Settings Screen */}
      <section id="paused" className="overlay modal-overlay hidden" aria-label="Pausa y ajustes">
        <div className="modal-panel pause-panel">
          <span className="eyebrow">TRANSMISIÓN EN ESPERA</span>
          <h2>Pausa y ajustes<span>.</span></h2>
          <p>Ajusta la sensibilidad de giro y apuntado a tu preferencia de juego.</p>
          <fieldset className="control-settings">
            <legend>CONTROL DE CÁMARA</legend>
            <label htmlFor="look-sensitivity">
              <span>Sensibilidad de cámara</span>
              <output id="look-value" htmlFor="look-sensitivity">100%</output>
            </label>
            <input id="look-sensitivity" type="range" min="30" max="180" step="5" defaultValue="100" />
            <label htmlFor="aim-sensitivity">
              <span>Sensibilidad al apuntar</span>
              <output id="aim-value" htmlFor="aim-sensitivity">65%</output>
            </label>
            <input id="aim-sensitivity" type="range" min="20" max="150" step="5" defaultValue="65" />
            <div className="settings-foot">
              <button id="center-look" type="button">Centrar mira</button>
              <button id="reset-controls" type="button">Restablecer</button>
              <span id="settings-saved" role="status">Se guarda automáticamente</span>
            </div>
          </fieldset>
          <div className="pause-actions">
            <button id="edit-joystick" className="joystick-settings-button" type="button">
              JOYSTICK<small>TAMAÑO Y POSICIÓN</small>
            </button>
            <a
              href="/DeadStrikeReborn-v3.0.apk"
              download="DeadStrikeReborn-v3.0.apk"
              className="joystick-settings-button"
              style={{ borderColor: '#22c55e', color: '#4ade80', textDecoration: 'none', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}
            >
              APK ANDROID<small>DESCARGAR .APK</small>
            </a>
            <button id="resume" className="primary-button">
              <span>Volver a la partida</span>
              <span aria-hidden="true">↗</span>
            </button>
          </div>
          <span className="modal-code">DSR / PAUSA</span>
        </div>
      </section>

      {/* End / Extraction Result Screen */}
      <section id="end" className="overlay modal-overlay hidden" aria-label="Fin de la partida">
        <div className="modal-panel end-panel">
          <span className="eyebrow">FIN DE LA TRANSMISIÓN</span>
          <h2 id="end-title">El distrito te reclama.</h2>
          <p id="end-detail">La niebla nunca descansa. Vuelve a intentarlo.</p>
          <div className="run-reward">
            <strong id="end-reward">Sin recompensa</strong>
            <span id="reward-persistence">Guardado en este navegador o app</span>
          </div>
          <div className="end-actions">
            <button id="restart" className="primary-button">
              <span>Volver al distrito</span>
              <span aria-hidden="true">↗</span>
            </button>
            <button id="end-shop" className="refuge-button">REFUGIO / TIENDA</button>
          </div>
          <span className="modal-code">DSR / FIN DEL RECORRIDO</span>
        </div>
      </section>

      {/* Route Fork Modal */}
      <section id="route" className="overlay modal-overlay hidden" aria-label="Elegir ruta de escape">
        <div className="modal-panel route-panel">
          <span className="eyebrow">BIFURCACIÓN / ELIGE UNA VEZ</span>
          <h2>Dos salidas<span>.</span></h2>
          <p>La corta te expone. La larga te da tiempo y suministros. No hay vuelta atrás.</p>
          <div className="route-options">
            <button id="route-short" className="route-card" type="button" data-route="short">
              <span className="route-tag">RIESGO ALTO</span>
              <strong>Ruta corta</strong>
              <span className="route-sub">Avenida directa</span>
              <span className="route-desc">Menos metros, más infectados. Sin suministros.</span>
              <span className="route-meta">+6 infectados · 0 cr extra</span>
            </button>
            <button id="route-long" className="route-card" type="button" data-route="long">
              <span className="route-tag">RIESGO MEDIO</span>
              <strong>Ruta larga</strong>
              <span className="route-sub">Desvío por la clínica</span>
              <span className="route-desc">El doble de camino, menos presión y un alijo de suministros.</span>
              <span className="route-meta">+15 cr al escapar</span>
            </button>
          </div>
          <span className="modal-code">DSR / BIFURCACIÓN</span>
        </div>
      </section>

      {/* Joystick Customizer & Store Overlays */}
      <section id="joystick-editor" className="overlay hidden" aria-label="Personalizar joystick" aria-hidden="true"></section>
      <section id="shop" className="overlay hidden" aria-label="Tienda del refugio"></section>
    </main>
  );
}
